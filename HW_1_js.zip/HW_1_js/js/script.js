'use strict';

let user = prompt ('Введите ваше имя'); 

alert (`Привет, ${ user } ! Шо ты там?`);